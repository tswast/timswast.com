Pixel Art Fox Emoji
===================

   Author: Tim Swast (www.timswast.com)
Published: 2018-12-01

These emoji were drawn for Alexandra Swast in 2017, released to the public on
December 1, 2018.

See https://www.timswast.com/blog/2018/12/01/fox-emoji/ for details.

License
-------

Copyright 2018, Tim Swast. Released under Creative Commons Attribution
License.

See LICENSE.txt for details.
